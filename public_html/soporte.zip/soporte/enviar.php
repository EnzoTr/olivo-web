<?php

require("class.phpmailer.php");
require("class.smtp.php");

$mail = new PHPMailer();
$mail->isSMTP();

$mail->Host = "mail.elolivobuffet.com.ar";
$mail->Port = 465;
$mail->SMTPAuth = true;
$mail->SMTPSecure = true;

$mail->Username = 'test@elolivobuffet.com.ar';
$mail->Password = 'wG^iBQiS3;OlPE1n.m';

$mail->From = 'test@elolivobuffet.com.ar';
$mail->FromName = "remitente";
$mail->AddAddress('reinaacaballo@gmail.com', "destinatario");

$mail->WordWrap = 50;
$mail->IsHTML(true);

$mail->Subject = "Asunto .....";
$mail->Body    = $_POST['algo'];

$mail->SMTPOptions = array(
'ssl' => array(
'verify_peer' => false,
'verify_peer_name' => false,
'allow_self_signed' => true
)
);


if(!$mail->Send())

{
   echo "Error al enviar. <p>";
   echo "Mailer Error: " . $mail->ErrorInfo;
   exit;
}

echo "Mensaje enviado!";

?> 
